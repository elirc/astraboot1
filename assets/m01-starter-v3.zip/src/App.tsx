import type {Adapter} from "./contracts";
export function Desk({adapter}:{adapter:Adapter}){void adapter;return <main><h1>Support ticket scaffold</h1><p>Implement the list, filter, create form, and routable detail using the supplied Adapter.</p></main>;}
