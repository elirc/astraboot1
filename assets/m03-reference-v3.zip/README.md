# M03: Ownership defect and regression — reference v3

This is a local training repository with fictional records. X-Training-User is a fixture identity, not production authentication. Servers bind to loopback. Do not publish this training API as an authenticated service.

## Assignment

Repair the deliberate owner-scoping defect. Alex must not read, edit, or comment on Morgan’s ticket. Lists must be scoped before pagination, unavailable resources consistently return 404, and rejected operations must change no rows or disclose foreign content. Keep owner operations working and retain safe request IDs.

## Setup

Use Node 24.21.0 (also verified locally with 22.16.0) and pnpm 10.17.1. Unzip into a new directory. These examples use PowerShell; use cp for Copy-Item on Bash. No paid service or AI API is needed.

~~~powershell
pnpm install --frozen-lockfile
Copy-Item .env.example .env
docker compose up -d db
pnpm db:generate
pnpm db:migrate
pnpm db:seed
pnpm db:seed
pnpm test:baseline
pnpm dev:api
# In another terminal: pnpm dev
~~~

Open http://127.0.0.1:5185. The API, when used, runs at http://127.0.0.1:4320. Baseline checks verify setup and fixtures. Mission checks deliberately fail in the starter until the assignment is implemented. The reference is expected to pass both. Configure the disposable database below before running M02 or M03 mission checks.

~~~sh
pnpm build
pnpm exec playwright install chromium
pnpm test:e2e
~~~

Before `pnpm test:e2e`, stop the Vite development server on port 5185 because Playwright starts its own. For M02 and M03, keep the training API running on port 4320.

## Disposable integration-test database

Mission tests clear fictional rows. They refuse to run unless DATABASE_URL and TEST_DATABASE_URL match and the database name contains _test. Create a separate database once:

~~~powershell
docker compose exec db createdb -U training support_desk_test
$env:DATABASE_URL="postgresql://training:training-local-only@127.0.0.1:5440/support_desk_test"
$env:TEST_DATABASE_URL=$env:DATABASE_URL
pnpm db:migrate
pnpm test:mission
~~~

If createdb reports that it already exists, reuse your disposable training database. After testing, remove these environment overrides in that terminal before starting the normal training API: Remove-Item Env:DATABASE_URL; Remove-Item Env:TEST_DATABASE_URL. On Bash use export NAME=value and unset NAME for the equivalent environment operations.

## Verification and troubleshooting

If a baseline fails, resolve installation, database readiness, migrations, or configuration first. A 501 MISSION_TODO response in M02 and failed ownership assertions in M03 are intentional assignment failures. Port conflicts: stop your own previous training server or update the matching Vite proxy and API port. A missing generated client requires pnpm db:generate. Do not point test variables at a database with real data.

## Reflection

Explain which state belongs to the form versus the server; which rules belong at request and database boundaries; and how your regression test distinguishes the original defect from the repaired behavior. Record the test command and observed result in DevPractice. Reports remain self-reported.
