import type {FastifyInstance} from "fastify";
export function registerTickets(app:FastifyInstance){app.all("/api/tickets",async(_req,reply)=>reply.code(501).send({error:{code:"MISSION_TODO",message:"Implement ticket collection handlers"}}));app.all("/api/tickets/*",async(_req,reply)=>reply.code(501).send({error:{code:"MISSION_TODO",message:"Implement detail and comment handlers"}}));}
