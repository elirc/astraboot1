# M01: Support ticket interface — reference v2

This is a local training repository with fictional records. X-Training-User is a fixture identity, not production authentication. Servers bind to loopback. Do not publish this training API as an authenticated service.

## Assignment

Implement the ticket list, status filter, trimmed nonblank title validation, duplicate-submit protection, creation refresh, and routable details. Loading, empty, error, and success states must be visible. Associate validation errors with fields, preserve drafts on failure, and verify keyboard use and a 360px viewport.

## Setup

Use Node 24.21.0 (also verified locally with 22.16.0) and pnpm 10.17.1. Unzip into a new directory. These examples use PowerShell; use cp for Copy-Item on Bash. No paid service or AI API is needed.

~~~powershell
pnpm install --frozen-lockfile
Copy-Item .env.example .env
pnpm test:baseline
pnpm dev
~~~

Open http://127.0.0.1:5185. The API, when used, runs at http://127.0.0.1:4320. Baseline checks verify setup and fixtures. Mission checks deliberately fail in the starter until the assignment is implemented. The reference is expected to pass both. Configure the disposable database below before running M02 or M03 mission checks.

~~~sh
pnpm test:mission
pnpm build
pnpm exec playwright install chromium
pnpm test:e2e
~~~

Before `pnpm test:e2e`, stop the Vite development server on port 5185 because Playwright starts its own. For M02 and M03, keep the training API running on port 4320.

## Verification and troubleshooting

If a baseline fails, resolve installation, database readiness, migrations, or configuration first. A 501 MISSION_TODO response in M02 and failed ownership assertions in M03 are intentional assignment failures. Port conflicts: stop your own previous training server or update the matching Vite proxy and API port. A missing generated client requires pnpm db:generate. Do not point test variables at a database with real data.

## Reflection

Explain which state belongs to the form versus the server; which rules belong at request and database boundaries; and how your regression test distinguishes the original defect from the repaired behavior. Record the test command and observed result in DevPractice. Reports remain self-reported.
