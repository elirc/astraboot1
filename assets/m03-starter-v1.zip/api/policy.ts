import type {Prisma} from "../generated/client/index.js";
// INTENTIONAL TRAINING DEFECT: reproduce the cross-user access before repairing this boundary.
export function ownedWhere(ownerId:string,id?:string):Prisma.TicketWhereInput{void ownerId;return id?{id}:{};}
