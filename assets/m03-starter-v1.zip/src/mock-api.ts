import {fixtures} from './fixtures';import {ApiError,validateTitle,type Adapter,type Detail} from './contracts';
export function createMockAdapter({delay=100,ownerId='alex',fail=false}:{delay?:number;ownerId?:string;fail?:boolean}={}):Adapter{
const tickets:Detail[]=structuredClone(fixtures);
const wait=(signal?:AbortSignal)=>new Promise<void>((resolve,reject)=>{if(signal?.aborted){reject(new DOMException('Cancelled','AbortError'));return;}const abort=()=>{clearTimeout(timer);reject(new DOMException('Cancelled','AbortError'));};const timer=setTimeout(()=>{signal?.removeEventListener('abort',abort);if(fail)reject(new ApiError('Fixture service unavailable',503));else resolve();},delay);signal?.addEventListener('abort',abort,{once:true});});
const find=(id:string)=>{const ticket=tickets.find(t=>t.id===id&&t.ownerId===ownerId);if(!ticket)throw new ApiError('Ticket unavailable',404);return ticket;};
return {
async list({status,cursor,limit=10,signal}){await wait(signal);const rows=tickets.filter(t=>t.ownerId===ownerId&&(!status||t.status===status)).sort((a,b)=>a.createdAt.localeCompare(b.createdAt)||a.id.localeCompare(b.id));const start=cursor?rows.findIndex(t=>t.id===cursor)+1:0;const page=rows.slice(start,start+limit);return structuredClone({items:page,nextCursor:start+limit<rows.length?page.at(-1)!.id:null});},
async detail(id,signal){await wait(signal);return structuredClone(find(id));},
async create(input){await wait();const error=validateTitle(input.title);if(error)throw new ApiError('Check input',422,{title:error});if(input.body.length>2000)throw new ApiError('Body is too long',422);const ticket:Detail={...input,title:input.title.trim(),id:crypto.randomUUID(),ownerId,status:'open',createdAt:new Date().toISOString(),comments:[]};tickets.push(ticket);return structuredClone(ticket);},
async comment(id,body){await wait();const ticket=find(id);if(!body.trim()||body.length>2000)throw new ApiError('Enter a comment of 1–2000 characters',422);const comment={id:crypto.randomUUID(),ticketId:id,body:body.trim(),createdAt:new Date().toISOString()};ticket.comments.push(comment);return structuredClone(comment);}
};}
